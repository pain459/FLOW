# PulsePay workload load-20261010T161333Z-974fd66b

Result: **PASS**; profile `soak`.
Integrity pre/post: PASS / PASS.
Measured seconds: 3600.000; achieved HTTP RPS: 20.133333333333333.
HTTP p50/p95/p99 ms: 46.0 / 84.0 / 103.0.
Confirmed logical commits: 28687; unknown: 0.

Warmup is excluded. Closed-loop operation ceiling is not an arrival guarantee. See manifest and underlying samples.

Failures: none
