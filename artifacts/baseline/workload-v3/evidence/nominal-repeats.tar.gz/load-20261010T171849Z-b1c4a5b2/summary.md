# PulsePay workload load-20261010T171849Z-b1c4a5b2

Result: **PASS**; profile `nominal`.
Integrity pre/post: PASS / PASS.
Measured seconds: 120.000; achieved HTTP RPS: 20.175.
HTTP p50/p95/p99 ms: 26.0 / 47.0 / 63.0.
Confirmed logical commits: 934; unknown: 0.

Warmup is excluded. Closed-loop operation ceiling is not an arrival guarantee. See manifest and underlying samples.

Failures: none
