# PulsePay workload load-20261010T172135Z-137cabdd

Result: **PASS**; profile `nominal`.
Integrity pre/post: PASS / PASS.
Measured seconds: 120.000; achieved HTTP RPS: 20.175.
HTTP p50/p95/p99 ms: 33.0 / 55.0 / 70.0.
Confirmed logical commits: 934; unknown: 0.

Warmup is excluded. Closed-loop operation ceiling is not an arrival guarantee. See manifest and underlying samples.

Failures: none
