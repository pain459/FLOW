# PulsePay workload load-20261010T184109Z-67498a30

Result: **PASS**; profile `nominal`.
Integrity pre/post: PASS / PASS.
Measured seconds: 90.000; achieved HTTP RPS: 20.033333333333335.
HTTP p50/p95/p99 ms: 10.0 / 24.0 / 30.0.
Confirmed logical commits: 681; unknown: 0.

Warmup is excluded. Closed-loop operation ceiling is not an arrival guarantee. See manifest and underlying samples.

Failures: none
