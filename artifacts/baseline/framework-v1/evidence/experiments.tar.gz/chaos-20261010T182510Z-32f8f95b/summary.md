# 008-postgres-outage — RESILIENCE_FAILURE

Run `chaos-20261010T182510Z-32f8f95b`. Independent integrity PASS → PASS. Restoration RESTORED. Impact observed: True. Recovery: FAIL.

Load `load-20261010T181731Z-659bf7a2`: AFTER_LOAD_REMOVAL_OR_UNKNOWN; external control intervention True. Framework journal alone does not establish recovery. Missing observations: load_network_rx, load_network_tx, load_rps, load_timeouts.
