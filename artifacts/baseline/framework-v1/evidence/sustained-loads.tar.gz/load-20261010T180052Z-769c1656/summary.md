# PulsePay workload load-20261010T180052Z-769c1656

Result: **FAILED**; profile `nominal`.
Integrity pre/post: PASS / PASS.
Measured seconds: 900.000; achieved HTTP RPS: 19.854444444444443.
HTTP p50/p95/p99 ms: 30.0 / 55.0 / 73.0.
Confirmed logical commits: 7070; unknown: 0.

Warmup is excluded. Closed-loop operation ceiling is not an arrival guarantee. See manifest and underlying samples.

Failures: none
