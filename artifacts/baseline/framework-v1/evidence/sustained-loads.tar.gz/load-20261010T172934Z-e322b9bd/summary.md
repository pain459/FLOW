# PulsePay workload load-20261010T172934Z-e322b9bd

Result: **FAILED**; profile `nominal`.
Integrity pre/post: PASS / PASS.
Measured seconds: 1800.000; achieved HTTP RPS: 19.755.
HTTP p50/p95/p99 ms: 32.0 / 56.0 / 83.0.
Confirmed logical commits: 14031; unknown: 0.

Warmup is excluded. Closed-loop operation ceiling is not an arrival guarantee. See manifest and underlying samples.

Failures: none
