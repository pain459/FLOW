# PulsePay workload load-20261010T181731Z-659bf7a2

Result: **FAILED**; profile `nominal`.
Integrity pre/post: PASS / PASS.
Measured seconds: 451.860; achieved HTTP RPS: 19.581292339430483.
HTTP p50/p95/p99 ms: 22.0 / 51.0 / 2612.0.
Confirmed logical commits: 3455; unknown: 51.

Warmup is excluded. Closed-loop operation ceiling is not an arrival guarantee. See manifest and underlying samples.

Failures: SUSTAINED_INFRASTRUCTURE_ERROR_RATE
