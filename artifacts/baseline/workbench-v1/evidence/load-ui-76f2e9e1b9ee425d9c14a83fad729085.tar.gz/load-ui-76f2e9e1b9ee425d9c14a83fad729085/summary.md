# PulsePay workload load-ui-76f2e9e1b9ee425d9c14a83fad729085

Result: **INCOMPLETE**; profile `nominal`.
Integrity pre/post: PASS / PASS.
Measured seconds: 74.609; achieved HTTP RPS: 19.515081520426598.
HTTP p50/p95/p99 ms: 10.0 / 23.0 / 28.0.
Confirmed logical commits: 554; unknown: 0.

Warmup is excluded. Closed-loop operation ceiling is not an arrival guarantee. See manifest and underlying samples.

Failures: MANUAL_UI_SESSION_NOT_A_QUALIFIED_BENCHMARK
