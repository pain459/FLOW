# PulsePay workload load-ui-ccb982d3ee8a4145a98ef751b57062a6

Result: **INCOMPLETE**; profile `nominal`.
Integrity pre/post: PASS / PASS.
Measured seconds: 120.587; achieved HTTP RPS: 19.66222224064054.
HTTP p50/p95/p99 ms: 9.0 / 21.0 / 31.0.
Confirmed logical commits: 906; unknown: 0.

Warmup is excluded. Closed-loop operation ceiling is not an arrival guarantee. See manifest and underlying samples.

Failures: MANUAL_UI_SESSION_NOT_A_QUALIFIED_BENCHMARK
